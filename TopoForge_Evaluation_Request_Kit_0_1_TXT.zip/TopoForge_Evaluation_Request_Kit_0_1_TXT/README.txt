# TopoForge FPGA Evaluation Request Kit 0.1

TopoForge FPGA is a protected interconnect technology preview.

This public kit does **not** contain the private build system, optimizer source code,
or a protected FPGA core. Instead, you describe the requested build and send the
request back to the TopoForge FPGA provider. A customer-specific ZIP is then prepared
for you.

## Current validated profile

- FPGA: Xilinx Spartan-6 XC6SLX9-2-TQG144
- Toolchain: Xilinx ISE 14.7
- Reference PE count: 40
- PE data width: 8 bit
- Reference clock: 50 MHz
- Interface: TF-IF-0.3
- Delivery format: protected `.ngc` + public wrapper/config/example/constraints/docs

## Quick start

1. Open `REQUEST_FORM.txt`.
2. Fill in the requested project information.
3. Send the completed request back to the TopoForge FPGA provider.
4. You receive a customer ZIP for evaluation.
5. Build it in a fresh ISE 14.7 project using the included quick-start instructions.

See `HOW_IT_WORKS.txt` and `SUPPORTED_PROFILE.txt` for details.
